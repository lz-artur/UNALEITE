import { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import RecepcaoLeite from './components/RecepcaoLeite';
import AnaliseLaboral from './components/AnaliseLaboral';
import LotesEstoqueDetalhado from './components/LotesEstoqueDetalhado';
import Producao from './components/Producao';
import Financeiro from './components/Financeiro';
import Placeholder from './components/Placeholder';

export default function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'recepcao':
        return <RecepcaoLeite />;
      case 'analise':
        return <AnaliseLaboral />;
      case 'lotes':
        return <LotesEstoqueDetalhado />;
      case 'producao':
        return <Producao />;
      case 'custos':
        return <Placeholder title="Custo de Produção" description="Análise detalhada de custos por ordem de produção" />;
      case 'comercial':
        return <Placeholder title="Comercial e Expedição" description="Gestão de vendas e expedição de produtos" />;
      case 'financeiro':
        return <Financeiro />;
      case 'folha-leite':
        return <Placeholder title="Folha do Leite" description="Cálculo de pagamento aos produtores" />;
      case 'dre':
        return <Placeholder title="DRE Gerencial" description="Demonstrativo de resultado do exercício" />;
      case 'cadastros':
        return <Placeholder title="Cadastros" description="Gerenciamento de cadastros básicos do sistema" />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout currentPage={currentPage} onNavigate={setCurrentPage}>
      {renderPage()}
    </Layout>
  );
}
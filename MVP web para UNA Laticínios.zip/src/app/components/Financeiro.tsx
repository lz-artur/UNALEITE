import { contasFinanceiras } from '../data/mockData';
import { Wallet, TrendingUp, TrendingDown, Calendar } from 'lucide-react';
import { format, isPast } from 'date-fns';

export default function Financeiro() {
  const contasPagar = contasFinanceiras.filter(c => c.tipo === 'Pagar');
  const contasReceber = contasFinanceiras.filter(c => c.tipo === 'Receber');

  const totalPagar = contasPagar
    .filter(c => c.status !== 'Pago' && c.status !== 'Cancelado')
    .reduce((sum, c) => sum + c.valor, 0);

  const totalReceber = contasReceber
    .filter(c => c.status !== 'Pago' && c.status !== 'Cancelado')
    .reduce((sum, c) => sum + c.valor, 0);

  const saldo = totalReceber - totalPagar;

  const getStatusColor = (conta: typeof contasFinanceiras[0]) => {
    if (conta.status === 'Pago') return 'bg-green-100 text-green-800';
    if (conta.status === 'Cancelado') return 'bg-gray-100 text-gray-800';
    if (conta.status === 'Vencido' || (conta.status === 'Aberto' && isPast(conta.dataVencimento))) {
      return 'bg-red-100 text-red-800';
    }
    return 'bg-yellow-100 text-yellow-800';
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Financeiro</h2>
        <p className="text-gray-600">Controle de contas a pagar e receber</p>
      </div>

      {/* Cards Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Contas a Pagar</p>
              <p className="text-2xl font-bold text-red-600">
                R$ {totalPagar.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <TrendingDown className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Contas a Receber</p>
              <p className="text-2xl font-bold text-green-600">
                R$ {totalReceber.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Saldo Previsto</p>
              <p className={`text-2xl font-bold ${saldo >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                R$ {saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Wallet className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Contas a Pagar */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-bold text-gray-900">Contas a Pagar</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descrição</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Categoria</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vencimento</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {contasPagar.map(conta => (
                <tr key={conta.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium">{conta.descricao}</td>
                  <td className="px-6 py-4 text-sm">{conta.categoria}</td>
                  <td className="px-6 py-4 font-medium text-red-600">
                    R$ {conta.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    {format(conta.dataVencimento, 'dd/MM/yyyy')}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(conta)}`}>
                      {conta.status === 'Aberto' && isPast(conta.dataVencimento) ? 'Vencido' : conta.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Contas a Receber */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-bold text-gray-900">Contas a Receber</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descrição</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Categoria</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vencimento</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {contasReceber.map(conta => (
                <tr key={conta.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium">{conta.descricao}</td>
                  <td className="px-6 py-4 text-sm">{conta.categoria}</td>
                  <td className="px-6 py-4 font-medium text-green-600">
                    R$ {conta.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    {format(conta.dataVencimento, 'dd/MM/yyyy')}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(conta)}`}>
                      {conta.status === 'Aberto' && isPast(conta.dataVencimento) ? 'Vencido' : conta.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

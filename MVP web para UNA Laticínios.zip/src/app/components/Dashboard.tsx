import { Milk, CheckCircle, XCircle, FileText, Package, DollarSign, Wallet, TrendingUp, FlaskConical } from 'lucide-react';
import { calcularEstatisticas } from '../data/mockData';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  color: 'blue' | 'green' | 'red' | 'yellow' | 'purple' | 'orange';
}

function StatCard({ title, value, icon, trend, color }: StatCardProps) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    red: 'bg-red-50 text-red-600',
    yellow: 'bg-yellow-50 text-yellow-600',
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600'
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mb-2">{value}</p>
          {trend && (
            <p className="text-xs text-gray-500">{trend}</p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          {icon}
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const stats = calcularEstatisticas();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-gray-600">Visão geral das operações - Maio 2026</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Leite Recebido no Mês"
          value={`${stats.leiteRecebidoMes.toLocaleString('pt-BR')} L`}
          icon={<Milk className="w-6 h-6" />}
          trend="+12% vs mês anterior"
          color="blue"
        />
        <StatCard
          title="Lotes Aprovados"
          value={stats.lotesAprovados}
          icon={<CheckCircle className="w-6 h-6" />}
          trend="Taxa de aprovação: 80%"
          color="green"
        />
        <StatCard
          title="Lotes Bloqueados"
          value={stats.lotesBloqueados}
          icon={<XCircle className="w-6 h-6" />}
          trend="Atenção: qualidade"
          color="red"
        />
        <StatCard
          title="OPs Abertas"
          value={stats.opsAbertas}
          icon={<FileText className="w-6 h-6" />}
          trend="Em andamento"
          color="yellow"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Produção Finalizada"
          value={stats.producaoFinalizada}
          icon={<Package className="w-6 h-6" />}
          trend="OPs concluídas este mês"
          color="purple"
        />
        <StatCard
          title="Custo Médio por Kg"
          value={`R$ ${stats.custoMedioKg.toFixed(2)}`}
          icon={<DollarSign className="w-6 h-6" />}
          trend="Média geral"
          color="orange"
        />
        <StatCard
          title="Valor da Folha do Leite"
          value={`R$ ${stats.folhaLeite.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={<Wallet className="w-6 h-6" />}
          trend="A pagar aos produtores"
          color="blue"
        />
        <StatCard
          title="Contas a Pagar"
          value={`R$ ${stats.contasPagar.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={<TrendingUp className="w-6 h-6" />}
          trend={`A receber: R$ ${stats.contasReceber.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          color="red"
        />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-bold text-gray-900 mb-4">Ações Rápidas</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all">
            <Milk className="w-5 h-5 text-blue-600" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Nova Recepção</p>
              <p className="text-xs text-gray-600">Registrar entrada de leite</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all">
            <FileText className="w-5 h-5 text-green-600" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Nova OP</p>
              <p className="text-xs text-gray-600">Criar ordem de produção</p>
            </div>
          </button>
          <button className="flex items-center gap-3 p-4 border-2 border-gray-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all">
            <FlaskConical className="w-5 h-5 text-purple-600" />
            <div className="text-left">
              <p className="font-medium text-gray-900">Análise Pendente</p>
              <p className="text-xs text-gray-600">Registrar análise laboratorial</p>
            </div>
          </button>
        </div>
      </div>

      {/* Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Package className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <h4 className="font-bold text-yellow-900 mb-1">Alerta de Estoque</h4>
              <p className="text-sm text-yellow-800 mb-2">
                1 insumo abaixo do estoque mínimo
              </p>
              <p className="text-xs text-yellow-700">Fermento Iogurte: 2 kg (mínimo: 5 kg)</p>
            </div>
          </div>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-xl p-6">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <XCircle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h4 className="font-bold text-red-900 mb-1">Lote Bloqueado</h4>
              <p className="text-sm text-red-800 mb-2">
                Lote LT-2026-003 bloqueado
              </p>
              <p className="text-xs text-red-700">Motivo: Antibiótico detectado</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

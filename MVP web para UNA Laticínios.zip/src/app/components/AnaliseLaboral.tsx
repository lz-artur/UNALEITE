import { useState } from 'react';
import { FlaskConical, AlertTriangle, CheckCircle } from 'lucide-react';
import { lotes, analises, getAnaliseByLoteId } from '../data/mockData';
import { format } from 'date-fns';

export default function AnaliseLaboral() {
  const [showModal, setShowModal] = useState(false);
  const [selectedLote, setSelectedLote] = useState<string | null>(null);

  const lotesAguardandoAnalise = lotes.filter(l => l.status === 'Aguardando Análise');

  const handleAnalyze = (loteId: string) => {
    setSelectedLote(loteId);
    setShowModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Análise Laboratorial</h2>
        <p className="text-gray-600">Registre os testes de qualidade e aprove/reprove lotes</p>
      </div>

      {/* Lotes Aguardando Análise */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
        <div className="flex items-start gap-3 mb-4">
          <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
          <div>
            <h3 className="font-bold text-yellow-900">Lotes Aguardando Análise</h3>
            <p className="text-sm text-yellow-800">
              {lotesAguardandoAnalise.length} lote(s) pendente(s) de análise laboratorial
            </p>
          </div>
        </div>
        {lotesAguardandoAnalise.length > 0 && (
          <div className="space-y-2">
            {lotesAguardandoAnalise.map(lote => (
              <div key={lote.id} className="bg-white rounded-lg p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900">{lote.codigo}</p>
                  <p className="text-sm text-gray-600">
                    Volume: {lote.volumeLitros.toLocaleString('pt-BR')} L |
                    Temp: {lote.temperatura.toFixed(1)}°C
                  </p>
                </div>
                <button
                  onClick={() => handleAnalyze(lote.id)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Realizar Análise
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Histórico de Análises */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-bold text-gray-900">Histórico de Análises</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Lote
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data Análise
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Alizarol
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acidez (°D)
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Antibióticos
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Gordura (%)
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Resultado
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {analises.map((analise) => {
                const lote = lotes.find(l => l.id === analise.loteId);
                return (
                  <tr key={analise.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{lote?.codigo}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {format(analise.dataAnalise, 'dd/MM/yyyy HH:mm')}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        analise.alizarol === 'Aprovado'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {analise.alizarol}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{analise.acidez}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        analise.antibioticos === 'Não Detectado'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {analise.antibioticos}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{analise.gordura?.toFixed(1)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        analise.aprovado
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {analise.aprovado ? 'Aprovado' : 'Reprovado'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Análise */}
      {showModal && selectedLote && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-xl font-bold text-gray-900">Análise Laboratorial</h3>
              <p className="text-sm text-gray-600">
                Lote: {lotes.find(l => l.id === selectedLote)?.codigo}
              </p>
            </div>
            <div className="p-6 space-y-6">
              {/* Testes Principais */}
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Testes de Qualidade</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Alizarol *
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                      <option value="">Selecione...</option>
                      <option value="Aprovado">Aprovado</option>
                      <option value="Reprovado">Reprovado</option>
                    </select>
                    <p className="text-xs text-red-600 mt-1">
                      Reprovado bloqueia o lote automaticamente
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Antibióticos *
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                      <option value="">Selecione...</option>
                      <option value="Não Detectado">Não Detectado</option>
                      <option value="Detectado">Detectado</option>
                    </select>
                    <p className="text-xs text-red-600 mt-1">
                      Detectado bloqueia o lote automaticamente
                    </p>
                  </div>
                </div>
              </div>

              {/* Análises Físico-Químicas */}
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Análises Físico-Químicas</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Acidez (°D)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="Ex: 16.0"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Crioscopia (°H)
                    </label>
                    <input
                      type="number"
                      step="0.001"
                      placeholder="Ex: -0.530"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Densidade (g/mL)
                    </label>
                    <input
                      type="number"
                      step="0.001"
                      placeholder="Ex: 1.028"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Gordura (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="Ex: 3.5"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Proteína (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      placeholder="Ex: 3.2"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      CBT (UFC/mL)
                    </label>
                    <input
                      type="number"
                      placeholder="Ex: 50000"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Observações */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observações
                </label>
                <textarea
                  rows={3}
                  placeholder="Observações adicionais sobre a análise..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Regras */}
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-bold text-red-900 mb-2">Regras de Bloqueio Automático</p>
                    <ul className="text-sm text-red-800 space-y-1">
                      <li>• Alizarol Reprovado → Lote bloqueado</li>
                      <li>• Antibiótico Detectado → Lote bloqueado</li>
                      <li>• Lotes bloqueados não podem ser usados na produção</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowModal(false);
                  setSelectedLote(null);
                }}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  setShowModal(false);
                  setSelectedLote(null);
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Salvar Análise
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';
import { lotes, insumos, estoquesProdutos, analises, precificacoes, produtores, getProdutoById, getProdutorById, getAnaliseByLoteId, getPrecificacaoByLoteId } from '../data/mockData';
import { AlertTriangle, Package, TrendingUp, TrendingDown, Award, DollarSign, Info } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';

export default function LotesEstoqueDetalhado() {
  const [selectedTab, setSelectedTab] = useState<'leite' | 'insumos' | 'produtos'>('leite');
  const [selectedLote, setSelectedLote] = useState<string | null>(null);

  const insumosAbaixoMinimo = insumos.filter(i => i.estoqueAtual < i.estoqueMinimo);

  // Calcular estatísticas dos lotes de leite
  const lotesComAnalise = lotes.filter(l => l.analiseId);
  const mediaGordura = lotesComAnalise.reduce((sum, lote) => {
    const analise = getAnaliseByLoteId(lote.id);
    return sum + (analise?.gordura || 0);
  }, 0) / lotesComAnalise.length;

  const mediaProteina = lotesComAnalise.reduce((sum, lote) => {
    const analise = getAnaliseByLoteId(lote.id);
    return sum + (analise?.proteina || 0);
  }, 0) / lotesComAnalise.length;

  const custoMedioLitro = lotes
    .filter(l => l.custoLitro)
    .reduce((sum, l) => sum + (l.custoLitro || 0), 0) / lotes.filter(l => l.custoLitro).length;

  // Calcular ranking de produtores por qualidade
  const rankingProdutores = produtores.map(produtor => {
    const lotesProdutor = lotes.filter(l => l.produtorId === produtor.id && l.analiseId);
    const volumeTotal = lotesProdutor.reduce((sum, l) => sum + l.volumeLitros, 0);

    const analisesProdutor = lotesProdutor.map(l => getAnaliseByLoteId(l.id)).filter(a => a);
    const gorduraMedia = analisesProdutor.reduce((sum, a) => sum + (a?.gordura || 0), 0) / analisesProdutor.length;
    const proteinaMedia = analisesProdutor.reduce((sum, a) => sum + (a?.proteina || 0), 0) / analisesProdutor.length;

    const precificacoesProdutor = lotesProdutor.map(l => getPrecificacaoByLoteId(l.id)).filter(p => p);
    const valorTotal = precificacoesProdutor.reduce((sum, p) => sum + (p?.valorTotal || 0), 0);
    const precoMedio = precificacoesProdutor.reduce((sum, p) => sum + (p?.precoFinal || 0), 0) / precificacoesProdutor.length;

    return {
      produtor,
      volumeTotal,
      gorduraMedia,
      proteinaMedia,
      valorTotal,
      precoMedio,
      qualidadeScore: (gorduraMedia * 0.5 + proteinaMedia * 0.5)
    };
  }).filter(r => r.volumeTotal > 0).sort((a, b) => b.qualidadeScore - a.qualidadeScore);

  const loteDetalhado = selectedLote ? lotes.find(l => l.id === selectedLote) : null;
  const analiseDetalhada = loteDetalhado ? getAnaliseByLoteId(loteDetalhado.id) : null;
  const precificacaoDetalhada = loteDetalhado ? getPrecificacaoByLoteId(loteDetalhado.id) : null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Lotes e Estoque</h2>
        <p className="text-gray-600">Gestão detalhada com composição, qualidade e precificação</p>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setSelectedTab('leite')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
              selectedTab === 'leite'
                ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Lotes de Leite Cru
          </button>
          <button
            onClick={() => setSelectedTab('insumos')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
              selectedTab === 'insumos'
                ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Insumos
          </button>
          <button
            onClick={() => setSelectedTab('produtos')}
            className={`flex-1 px-6 py-3 text-sm font-medium transition-colors ${
              selectedTab === 'produtos'
                ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Produtos Acabados
          </button>
        </div>
      </div>

      {/* Alertas */}
      {insumosAbaixoMinimo.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-bold text-yellow-900 mb-2">Alerta de Estoque Mínimo</h3>
              <div className="space-y-1">
                {insumosAbaixoMinimo.map(insumo => (
                  <p key={insumo.id} className="text-sm text-yellow-800">
                    • {insumo.nome}: {insumo.estoqueAtual} {insumo.unidade} (mínimo: {insumo.estoqueMinimo} {insumo.unidade})
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Conteúdo por Tab */}
      {selectedTab === 'leite' && (
        <div className="space-y-6">
          {/* Indicadores de Qualidade */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Gordura Média</p>
                  <p className="text-2xl font-bold text-gray-900">{mediaGordura.toFixed(2)}%</p>
                  <p className="text-xs text-gray-500 mt-1">Composição do leite</p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Proteína Média</p>
                  <p className="text-2xl font-bold text-gray-900">{mediaProteina.toFixed(2)}%</p>
                  <p className="text-xs text-gray-500 mt-1">Composição do leite</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Custo Médio/Litro</p>
                  <p className="text-2xl font-bold text-gray-900">R$ {custoMedioLitro.toFixed(2)}</p>
                  <p className="text-xs text-gray-500 mt-1">Precificação diferenciada</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <DollarSign className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </div>
          </div>

          {/* Tabela de Lotes */}
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <h3 className="font-bold text-gray-900">Lotes de Leite com Composição e Precificação</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lote</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produtor</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gordura</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Proteína</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Custo/L</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor Total</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {lotes.map(lote => {
                    const produtor = getProdutorById(lote.produtorId);
                    const analise = getAnaliseByLoteId(lote.id);

                    return (
                      <tr key={lote.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap font-medium">{lote.codigo}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{produtor?.nome}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm">
                            <div className="font-medium">{lote.volumeLitros.toLocaleString('pt-BR')} L</div>
                            {lote.volumeDisponivel !== undefined && (
                              <div className="text-xs text-gray-500">
                                Disp: {lote.volumeDisponivel.toLocaleString('pt-BR')} L
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {analise?.gordura ? (
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              analise.gordura >= 3.5 ? 'bg-green-100 text-green-800' :
                              analise.gordura >= 3.0 ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {analise.gordura.toFixed(1)}%
                            </span>
                          ) : '—'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {analise?.proteina ? (
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              analise.proteina >= 3.2 ? 'bg-green-100 text-green-800' :
                              analise.proteina >= 3.0 ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {analise.proteina.toFixed(1)}%
                            </span>
                          ) : '—'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-medium">
                          {lote.custoLitro ? `R$ ${lote.custoLitro.toFixed(2)}` : '—'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-medium text-green-600">
                          {lote.valorTotal ? `R$ ${lote.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : '—'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            lote.status === 'Aprovado' || lote.status === 'Parcialmente Utilizado' ? 'bg-green-100 text-green-800' :
                            lote.status === 'Aguardando Análise' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {lote.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <button
                            onClick={() => setSelectedLote(lote.id)}
                            className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                          >
                            Ver Detalhes
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Ranking de Produtores */}
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <h3 className="font-bold text-gray-900">Ranking de Produtores por Qualidade</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ranking</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produtor</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume Total</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Gordura Média</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Proteína Média</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Preço Médio/L</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {rankingProdutores.map((rank, index) => (
                    <tr key={rank.produtor.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          {index === 0 && <Award className="w-5 h-5 text-yellow-500" />}
                          <span className="font-bold text-lg">{index + 1}º</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-medium">{rank.produtor.nome}</td>
                      <td className="px-6 py-4">{rank.volumeTotal.toLocaleString('pt-BR')} L</td>
                      <td className="px-6 py-4">
                        <span className="font-medium text-green-600">{rank.gorduraMedia.toFixed(2)}%</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-medium text-blue-600">{rank.proteinaMedia.toFixed(2)}%</span>
                      </td>
                      <td className="px-6 py-4">R$ {rank.precoMedio.toFixed(2)}</td>
                      <td className="px-6 py-4 font-medium text-green-600">
                        R$ {rank.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {selectedTab === 'insumos' && (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-bold text-gray-900">Estoque de Insumos (FEFO)</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Insumo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estoque</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mínimo</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Validade</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {insumos.map(insumo => {
                  const diasValidade = insumo.dataValidade ? differenceInDays(insumo.dataValidade, new Date()) : null;
                  const abaixoMinimo = insumo.estoqueAtual < insumo.estoqueMinimo;
                  const proximoVencimento = diasValidade !== null && diasValidade < 30;

                  return (
                    <tr key={insumo.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">{insumo.nome}</td>
                      <td className="px-6 py-4 text-sm">{insumo.tipo}</td>
                      <td className="px-6 py-4">
                        <span className={abaixoMinimo ? 'text-red-600 font-medium' : ''}>
                          {insumo.estoqueAtual} {insumo.unidade}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {insumo.estoqueMinimo} {insumo.unidade}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        {insumo.dataValidade ? format(insumo.dataValidade, 'dd/MM/yyyy') : '—'}
                      </td>
                      <td className="px-6 py-4">
                        {abaixoMinimo && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                            Baixo
                          </span>
                        )}
                        {proximoVencimento && !abaixoMinimo && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                            Vence em {diasValidade}d
                          </span>
                        )}
                        {!abaixoMinimo && !proximoVencimento && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                            OK
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {selectedTab === 'produtos' && (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-bold text-gray-900">Estoque de Produtos Acabados</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lote</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produzido</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disponível</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Validade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {estoquesProdutos.map(estoque => {
                  const produto = getProdutoById(estoque.produtoId);
                  const diasValidade = differenceInDays(estoque.dataValidade, new Date());

                  return (
                    <tr key={estoque.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">{produto?.nome}</td>
                      <td className="px-6 py-4 text-sm">{estoque.lote}</td>
                      <td className="px-6 py-4">{estoque.quantidade} {produto?.unidade}</td>
                      <td className="px-6 py-4 font-medium text-green-600">
                        {estoque.disponivel} {produto?.unidade}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-sm ${diasValidade < 3 ? 'text-red-600 font-medium' : diasValidade < 7 ? 'text-yellow-600' : ''}`}>
                          {format(estoque.dataValidade, 'dd/MM/yyyy')}
                          {diasValidade < 7 && ` (${diasValidade}d)`}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal de Detalhes do Lote */}
      {selectedLote && loteDetalhado && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Detalhes do Lote {loteDetalhado.codigo}</h3>
                  <p className="text-sm text-gray-600">
                    Produtor: {getProdutorById(loteDetalhado.produtorId)?.nome}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedLote(null)}
                  className="p-2 hover:bg-gray-100 rounded-lg"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Informações Básicas */}
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Informações da Entrada</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Volume Total:</span>
                    <p className="font-medium">{loteDetalhado.volumeLitros.toLocaleString('pt-BR')} litros</p>
                  </div>
                  <div>
                    <span className="text-gray-600">Volume Disponível:</span>
                    <p className="font-medium">{loteDetalhado.volumeDisponivel?.toLocaleString('pt-BR')} litros</p>
                  </div>
                  <div>
                    <span className="text-gray-600">Temperatura:</span>
                    <p className="font-medium">{loteDetalhado.temperatura.toFixed(1)}°C</p>
                  </div>
                  <div>
                    <span className="text-gray-600">Data de Recebimento:</span>
                    <p className="font-medium">{format(loteDetalhado.dataHoraRecebimento, 'dd/MM/yyyy HH:mm')}</p>
                  </div>
                </div>
              </div>

              {/* Análise de Qualidade */}
              {analiseDetalhada && (
                <div>
                  <h4 className="font-bold text-gray-900 mb-3">Análise de Qualidade</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Gordura</p>
                      <p className="text-lg font-bold text-green-600">{analiseDetalhada.gordura?.toFixed(2)}%</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Proteína</p>
                      <p className="text-lg font-bold text-blue-600">{analiseDetalhada.proteina?.toFixed(2)}%</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Acidez</p>
                      <p className="text-lg font-bold text-gray-900">{analiseDetalhada.acidez}°D</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">CBT</p>
                      <p className="text-lg font-bold text-gray-900">{analiseDetalhada.cbt?.toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">CCS</p>
                      <p className="text-lg font-bold text-gray-900">{analiseDetalhada.ccs?.toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Crioscopia</p>
                      <p className="text-lg font-bold text-gray-900">{analiseDetalhada.crioscopia}°H</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Precificação */}
              {precificacaoDetalhada && (
                <div>
                  <h4 className="font-bold text-gray-900 mb-3">Precificação Diferenciada</h4>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Preço Base:</span>
                      <span className="font-medium">R$ {precificacaoDetalhada.precoBase.toFixed(2)}/L</span>
                    </div>
                    {precificacaoDetalhada.bonusGordura > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Bônus Gordura:</span>
                        <span className="font-medium">+ R$ {precificacaoDetalhada.bonusGordura.toFixed(2)}/L</span>
                      </div>
                    )}
                    {precificacaoDetalhada.bonusProteina > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Bônus Proteína:</span>
                        <span className="font-medium">+ R$ {precificacaoDetalhada.bonusProteina.toFixed(2)}/L</span>
                      </div>
                    )}
                    {precificacaoDetalhada.penalizacaoCCS < 0 && (
                      <div className="flex justify-between text-red-600">
                        <span>Penalização CCS:</span>
                        <span className="font-medium">R$ {precificacaoDetalhada.penalizacaoCCS.toFixed(2)}/L</span>
                      </div>
                    )}
                    {precificacaoDetalhada.penalizacaoCBT < 0 && (
                      <div className="flex justify-between text-red-600">
                        <span>Penalização CBT:</span>
                        <span className="font-medium">R$ {precificacaoDetalhada.penalizacaoCBT.toFixed(2)}/L</span>
                      </div>
                    )}
                    {precificacaoDetalhada.penalizacaoAcidez < 0 && (
                      <div className="flex justify-between text-red-600">
                        <span>Penalização Acidez:</span>
                        <span className="font-medium">R$ {precificacaoDetalhada.penalizacaoAcidez.toFixed(2)}/L</span>
                      </div>
                    )}
                    <div className="border-t border-blue-300 pt-2 flex justify-between font-bold">
                      <span>Preço Final:</span>
                      <span>R$ {precificacaoDetalhada.precoFinal.toFixed(2)}/L</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg text-green-600">
                      <span>Valor Total:</span>
                      <span>R$ {precificacaoDetalhada.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

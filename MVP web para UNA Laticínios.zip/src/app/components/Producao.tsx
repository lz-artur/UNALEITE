import { useState } from 'react';
import { Plus, Factory, TrendingUp, TrendingDown } from 'lucide-react';
import { ordensProducao, lotes, produtos, getProdutoById, getLoteById } from '../data/mockData';
import { format } from 'date-fns';

export default function Producao() {
  const [showModal, setShowModal] = useState(false);

  const lotesAprovados = lotes.filter(l => l.status === 'Aprovado');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Produção</h2>
          <p className="text-gray-600">Ordens de Produção e controle de rendimento</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
          Nova OP
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-yellow-50 rounded-lg">
              <Factory className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">OPs em Andamento</p>
              <p className="text-2xl font-bold text-gray-900">
                {ordensProducao.filter(op => op.status === 'Em Andamento').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-50 rounded-lg">
              <Factory className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">OPs Finalizadas</p>
              <p className="text-2xl font-bold text-gray-900">
                {ordensProducao.filter(op => op.status === 'Finalizada').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Rendimento Médio</p>
              <p className="text-2xl font-bold text-gray-900">
                {(ordensProducao
                  .filter(op => op.rendimentoReal)
                  .reduce((sum, op) => sum + (op.rendimentoReal || 0), 0) /
                  ordensProducao.filter(op => op.rendimentoReal).length
                ).toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Lista de OPs */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-bold text-gray-900">Ordens de Produção</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Número</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lote Leite</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Litros Usados</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produzido</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rendimento</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {ordensProducao.map(op => {
                const produto = getProdutoById(op.produtoId);
                const lote = getLoteById(op.loteLeiteId);
                const rendimentoDiferenca = op.rendimentoReal && produto
                  ? ((op.rendimentoReal - produto.rendimentoTeorico) / produto.rendimentoTeorico * 100)
                  : 0;

                return (
                  <tr key={op.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap font-medium">{op.numero}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{produto?.nome}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{lote?.codigo}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{op.litrosUtilizados.toLocaleString('pt-BR')} L</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {op.quantidadeProduzida ? `${op.quantidadeProduzida} ${produto?.unidade}` : '—'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {op.rendimentoReal ? (
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{op.rendimentoReal.toFixed(2)}</span>
                          {rendimentoDiferenca !== 0 && (
                            <span className={`flex items-center text-xs ${
                              rendimentoDiferenca > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {rendimentoDiferenca > 0 ? (
                                <TrendingUp className="w-3 h-3 mr-0.5" />
                              ) : (
                                <TrendingDown className="w-3 h-3 mr-0.5" />
                              )}
                              {Math.abs(rendimentoDiferenca).toFixed(1)}%
                            </span>
                          )}
                        </div>
                      ) : '—'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        op.status === 'Finalizada' ? 'bg-green-100 text-green-800' :
                        op.status === 'Em Andamento' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {op.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Nova OP */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-xl font-bold text-gray-900">Nova Ordem de Produção</h3>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Lote de Leite Aprovado *
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Selecione...</option>
                    {lotesAprovados.map(lote => (
                      <option key={lote.id} value={lote.id}>
                        {lote.codigo} - {lote.volumeLitros.toLocaleString('pt-BR')} L
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Produto *
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Selecione...</option>
                    {produtos.filter(p => p.ativo).map(produto => (
                      <option key={produto.id} value={produto.id}>
                        {produto.nome}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Litros de Leite a Utilizar *
                </label>
                <input
                  type="number"
                  placeholder="0"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Rendimento Teórico:</strong> Será calculado automaticamente com base no produto selecionado.
                  Após finalizar a OP, você poderá informar a quantidade produzida para calcular o rendimento real.
                </p>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 flex gap-3 justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Criar OP
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
